package nicpack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginUser
 */
@WebServlet("/LoginUser")
public class LoginUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{	
			PrintWriter out = response.getWriter();
		String email = request.getParameter("email");
	
	      String password = request.getParameter("pass");
	    
	      if(email != "" && password != "")
	      {
	    	  response.setContentType("text/html");
	    	Class.forName("com.mysql.cj.jdbc.Driver");
				java.sql.Connection con =  DriverManager.getConnection
				    ("jdbc:mysql://localhost:3306/nic_internship","nic_internship","nic_internship");
				 PreparedStatement stmt=con.prepareStatement("SELECT name FROM member_register  "
			          		+ "WHERE email = ? AND PASSWORD = ?");
				      stmt.setString(1,email);
				      stmt.setString(2,password);
				      ResultSet rs=stmt.executeQuery(); 
				   
				  if(rs.next()){
				  request.setAttribute("myname",email);
			      request.getRequestDispatcher("welcome_user.jsp").forward(request, response);
				  }
				  else{
					  out.print("Wrong email or password");
				  }
	      }
	      else{
	    	  out.print("NULL VALUES");
	      }
	      }
		catch(Exception e){
			System.out.println(e);
		}
	}
}
