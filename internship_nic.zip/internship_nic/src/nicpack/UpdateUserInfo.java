package nicpack;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateUserInfo
 */
@WebServlet("/UpdateUserInfo")
public class UpdateUserInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Object a = request.getParameter("myname123");
		String forwardemail = a.toString();
	    String dob = request.getParameter("bday");
	   String gender = request.getParameter("gender");
	   
	    try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			java.sql.Connection con =  DriverManager.getConnection
					("jdbc:mysql://localhost:3306/nic_internship","nic_internship","nic_internship");
			PreparedStatement stmt=con.prepareStatement("update member_register set dob=?, gender=? where email=?");
			
		      stmt.setString(1,dob);
		      
		      stmt.setString(2,gender);
		     
		      stmt.setString(3,forwardemail);
		      
		      stmt.executeUpdate();
		      
		      request.setAttribute("myname",forwardemail);
		      request.getRequestDispatcher("welcome_user.jsp").forward(request, response);
		} 
	    catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
