package nicpack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/DailyAttendence")
public class DailyAttendence extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request1, HttpServletResponse response1) throws ServletException, IOException {
		// TODO Auto-generated method stub
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");  
		LocalDateTime now = LocalDateTime.now(); 
		String abc = dtf.format(now);
		String result = abc.split("T")[0];
	//	System.out.println(result);
		
	    Object u = request1.getParameter("uniquemail");
		String uniquemail = u.toString();
		//System.out.println(uniquemail);
		try{	
			int a=1;
			String present = null;
			Object d = request1.getParameter("attendance");
			Object t = request1.getParameter("uniquetime");
			String dailytime=t.toString();
			String daily = d.toString();
			//System.out.println(dailytime);
			PrintWriter out = response1.getWriter();
		 response1.setContentType("text/html");
	    	Class.forName("com.mysql.cj.jdbc.Driver");
				java.sql.Connection con =  DriverManager.getConnection
				    ("jdbc:mysql://localhost:3306/nic_internship","nic_internship","nic_internship");
			
				PreparedStatement st = con.prepareStatement("SELECT DATE FROM ATTENDENCE WHERE EMAIL=?");
				st.setString(1,uniquemail);
				ResultSet resultset = st.executeQuery() ; 
		while(resultset.next()){
			String z=resultset.getString(1);
			System.out.println(z);
		if(z.equals(result))
			 a=2;
			// out.println( "present date "+resultset.getString(1));
			 //out.println(" ");
		}
		if(a==1){
				 PreparedStatement stmt=con.prepareStatement("insert into attendence values (?,?,?)");
			
				 stmt.setString(1,uniquemail);
				 stmt.setString(2, daily);
	             stmt.setString(3, dailytime);
				 stmt.addBatch();
				 stmt.executeBatch();

				request1.setAttribute("myname",uniquemail);
	              out.println("Attendance Made");	
	              request1.getRequestDispatcher("attendancemade.jsp").forward(request1, response1);
		}
		else{
			request1.setAttribute("myname",uniquemail);
			request1.getRequestDispatcher("attendancemade.jsp").forward(request1, response1);;
			//response1.sendRedirect("attendancemade.jsp");
		}
		}
	catch(Exception e){
	     System.out.println(e);
	}
		
}
	}
