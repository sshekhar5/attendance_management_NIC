package nicpack;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginAdmin
 */
@WebServlet("/LoginAdmin")
public class LoginAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{	
			PrintWriter out = response.getWriter();
		String username = request.getParameter("username");
	      String password = request.getParameter("pass");
	      if(username != "" && password != "")
	      {
	    	  response.setContentType("text/html");
	    	Class.forName("com.mysql.cj.jdbc.Driver");
				java.sql.Connection con =  DriverManager.getConnection
				    ("jdbc:mysql://localhost:3306/nic_internship","nic_internship","nic_internship");
				 PreparedStatement stmt=con.prepareStatement("SELECT USERNAME FROM ADMIN  "
			          		+ "WHERE USERNAME = ? AND PASSWORD = ?");
				      stmt.setString(1,username);
				      stmt.setString(2,password);
				      ResultSet rs=stmt.executeQuery();
				      if(rs.next()){
				    	  request.setAttribute("myname",username);
					      
					      request.getRequestDispatcher("adminwelcome.jsp").forward(request, response);
				      }
				      else{
				    	  out.print("Wrong Username & Password");
				      }
	      }
	      else{
	    	  out.print("NULL VALUES");
	      }
	     
	      }
		catch(Exception e){
			System.out.println(e);
		}
		}
}
