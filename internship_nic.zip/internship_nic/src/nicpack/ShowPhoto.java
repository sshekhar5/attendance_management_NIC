package nicpack;

import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Base64;
import java.util.Base64.Decoder;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

import sun.misc.BASE64Decoder;

/**
 * Servlet implementation class ShowPhoto
 */
@WebServlet("/ShowPhoto")
public class ShowPhoto extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			PrintWriter out = response.getWriter(); 
		       Class.forName("com.mysql.cj.jdbc.Driver");
				java.sql.Connection con =  DriverManager.getConnection
				    ("jdbc:mysql://localhost:3306/nic_internship","nic_internship","nic_internship");
				
			String mailobj = request.getParameter("mailme");
			String mailname = mailobj.toString();
			//System.out.println(mailname);
				 // Statement stmt1 = con.createStatement();
			
			PreparedStatement stmt1 = con.prepareStatement("select * from profile_pic where email = ? ");
			stmt1.setString(1,mailname);
			ResultSet rst = stmt1.executeQuery();    	
			    	while(rst.next()){
			    		//System.out.println("hiii");
			    		String b64 = rst.getString("propic");
			    		String b64img = b64.toString();
			    	
			    		byte[] btDataFile = new sun.misc.BASE64Decoder().decodeBuffer(b64img);
			    		File of = new File("C:\\Users\\Shashank Shekhar\\Desktop\\MyServletPrg\\internship_nic\\"
			    				+ "WebContent\\images\\profile_pic//"+mailname+".png");
			    		FileOutputStream osf = new FileOutputStream(of);
			    		osf.write(btDataFile);
			    		osf.flush();
			// response.sendRedirect("redirectToUserLoginPage.jsp");
			    		request.setAttribute("myname", mailname);
			    		request.getRequestDispatcher("redirectToUserLoginPage.jsp").forward(request, response);
			}	
			  
			 
		}
	
		catch(Exception e){
			System.out.println(e);
		}
	}

}
