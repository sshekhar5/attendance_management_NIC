package nicpack;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Base64;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.tomcat.util.http.fileupload.IOUtils;

/**
 * Servlet implementation class SetPhoto1
 */
@WebServlet("/SetPhoto1")
@MultipartConfig(maxFileSize = 16177215)
public class SetPhoto1 extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
   
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{
       PrintWriter out = response.getWriter(); 
       Class.forName("com.mysql.cj.jdbc.Driver");
		java.sql.Connection con =  DriverManager.getConnection
		    ("jdbc:mysql://localhost:3306/nic_internship","nic_internship","nic_internship");
		
		String mail = request.getParameter("mailme");
		int a=1;
          InputStream inputStream = null; // input stream of the upload file
          // obtains the upload file part in this multipart request
          Part filePart = request.getPart("myFile");
          if (filePart != null) {
              inputStream = filePart.getInputStream();
          }
                 
         byte[] targetArray = new byte[inputStream.available()];
          InputStream is = new BufferedInputStream(inputStream);
          is.read(targetArray);
          String base64Encoded = Base64.getEncoder().encodeToString(targetArray);
        //  System.out.println(base64Encoded);
          PreparedStatement stmt2 = con.prepareStatement("SELECT * FROM profile_pic where email = ? ");
          stmt2.setString(1, mail);
          ResultSet rs = stmt2.executeQuery();
          while(rs.next()){
        	   a=2;
          PreparedStatement stmt1=con.prepareStatement("update profile_pic set propic = ? where email = ?");
         stmt1.setString(1, base64Encoded);
          stmt1.setString(2, mail);
          //stmt1.addBatch();
          stmt1.executeUpdate();
       //   out.print("updated");
        //  response.sendRedirect("profilepic_saved.jsp");
          request.setAttribute("emailname5", mail);
          request.getRequestDispatcher("profilepic_saved.jsp").forward(request, response);
	}
        if(a==1){
        	PreparedStatement stmt3=con.prepareStatement("insert into profile_pic values(?,?)");
            stmt3.setString(1, mail);
             stmt3.setString(2, base64Encoded);
             stmt3.addBatch();
             stmt3.executeBatch();
             out.print("inserted");
             request.setAttribute("emailname5", mail);
             request.getRequestDispatcher("profilepic_saved.jsp").forward(request, response);
        }
		}
	
	
	catch(Exception e){
		System.out.println(e);
	}
  /*  private static String encodeFileToBase64Binary(File file){
        String encodedfile = null;
        try {
            FileInputStream fileInputStreamReader = new FileInputStream(file);
            byte[] bytes = new byte[(int)file.length()];
            fileInputStreamReader.read(bytes);
            encodedfile = Base64.getEncoder().encodeToString(bytes);
        } catch (FileNotFoundException e) {
           
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return encodedfile;
    }*/


}
}