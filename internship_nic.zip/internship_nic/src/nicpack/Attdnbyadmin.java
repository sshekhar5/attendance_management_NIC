package nicpack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Attdnbyadmin
 */
@WebServlet("/Attdnbyadmin")
public class Attdnbyadmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String a = request.getParameter("uniquemail");
		String b = request.getParameter("attendance");
		String c = request.getParameter("settime");
try{
	Class.forName("com.mysql.cj.jdbc.Driver");
	java.sql.Connection con =  DriverManager.getConnection
	    ("jdbc:mysql://localhost:3306/nic_internship","nic_internship","nic_internship");
	    
	    
	 PreparedStatement stmt=con.prepareStatement("insert into attendence values (?,?,?)");
		
	 stmt.setString(1,a);
	 stmt.setString(2, b);
     stmt.setString(3, c);
	 stmt.addBatch();
	 stmt.executeBatch();

	request.setAttribute("myname",a);
      out.println("Attendance Made");	
}
catch(Exception e){
	System.out.println(e);
}
	}

}
