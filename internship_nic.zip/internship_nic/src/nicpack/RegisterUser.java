package nicpack;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterUser
 */
@WebServlet("/RegisterUser")
public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		try{
			Object a = request.getParameter("myname123");
			String forwardusername = a.toString();

		 String name = request.getParameter("mname");
		 String password = request.getParameter("mpass");
		 String confirmpassword = request.getParameter("passconfirm");
	      String email = request.getParameter("memail");
	      String job = request.getParameter("mjob");
	      String contact = request.getParameter("mmob");
	     // FileInputStream fin=new FileInputStream("");
	      String dob = "EMPTY";
	      String gender = "EMPTY";
	      int id = 0;
	      if(request.getParameter("mpass").equals((request).getParameter("passconfirm"))){
	    	  response.setContentType("text/html");
	    	  Class.forName("com.mysql.cj.jdbc.Driver");
				java.sql.Connection con =  DriverManager.getConnection
				   
						("jdbc:mysql://localhost:3306/nic_internship","nic_internship","nic_internship");
				Statement stmt1=con.createStatement(); 
				ResultSet rs=stmt1.executeQuery("select max(id) from member_register");  
				while (rs.next()) {
					id= rs.getInt(1);
					id= id+1;
					//System.out.println(id);
                     break;
				} 
				PreparedStatement stmt=con.prepareStatement("INSERT INTO member_register VALUES(?,?,?,?,?,?,?,?)");
				
				  stmt.setInt(1, id);
				
			      stmt.setString(2,name);
			     
			      stmt.setString(3,email);
			      
			      stmt.setString(4,password);
			      
			      stmt.setString(5,job);
			      
			      stmt.setString(6,contact);
			      
			//      stmt.setBinaryStream(7,fin,fin.available());
			      
			      stmt.setString(7, dob);
			      
			      stmt.setString(8, gender);
			      
			      stmt.executeUpdate();
			      
			      request.setAttribute("myname",forwardusername);
			      request.getRequestDispatcher("adminwelcome.jsp").forward(request, response);
			    
	      }
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

}
