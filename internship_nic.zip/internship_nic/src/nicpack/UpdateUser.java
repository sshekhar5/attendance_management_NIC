package nicpack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateUser
 */
@WebServlet("/UpdateUser")
public class UpdateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		try{
		 String name = request.getParameter("mname");
		 String password = request.getParameter("mpass");
		 String confirmpassword = request.getParameter("passconfirm");
	      String email = request.getParameter("memail");
	      String job = request.getParameter("mjob");
	      String contact = request.getParameter("mmob");
	      String id=request.getParameter("getid");
	     
	      if(request.getParameter("mpass").equals((request).getParameter("passconfirm"))){
	    	  response.setContentType("text/html");
	    	  Class.forName("com.mysql.cj.jdbc.Driver");
				java.sql.Connection con =  DriverManager.getConnection
				   
						("jdbc:mysql://localhost:3306/nic_internship","nic_internship","nic_internship");
				Statement stmt1=con.createStatement(); 
				
				PreparedStatement stmt=con.prepareStatement("update member_register "
						+ "set name=?, email=?, password=?, job=?, contact=? where id=?");
				
				 
				
			      stmt.setString(1,name);
			     
			      stmt.setString(2,email);
			      
			      stmt.setString(3,password);
			      
			      stmt.setString(4,job);
			      
			      stmt.setString(5,contact);
			      
			      stmt.setString(6, id);
			     
			      stmt.executeUpdate();
			      
			      response.sendRedirect("adminwelcome.jsp"); 
	      }
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

	}