package nicpack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeleteUser
 */
@WebServlet("/DeleteUser")
public class DeleteUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		try{	
			PrintWriter out = response.getWriter();
		String id = request.getParameter("delid");
	      
	    	  response.setContentType("text/html");
	    	Class.forName("com.mysql.cj.jdbc.Driver");
				java.sql.Connection con =  DriverManager.getConnection
				    ("jdbc:mysql://localhost:3306/nic_internship","nic_internship","nic_internship");
	PreparedStatement stmt=con.prepareStatement("DELETE FROM member_register WHERE id = ?");
	stmt.setString(1,id);	 
				 stmt.executeUpdate();
				 response.sendRedirect("adminwelcome.jsp");
	}
		catch(Exception e){
			System.out.println(e);
		}

}
}